from django.contrib import admin
from store.models.product import Products
from .models.category import Category
from .models.customer import Customer_info
from .models.orders import Orders


class adminProducts(admin.ModelAdmin):
    list_display = ("name" , "price", "category" ,"image")

class adminCategory(admin.ModelAdmin):
    list_display = ("name",)
# Register your models here.
admin.site.register(Products , adminProducts)
admin.site.register(Category , adminCategory)
admin.site.register(Customer_info)
admin.site.register(Orders)