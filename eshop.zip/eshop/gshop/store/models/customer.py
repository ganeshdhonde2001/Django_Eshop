from django.db import models

class Customer_info(models.Model):
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)
    mobilenumber = models.CharField(max_length=15)
    email = models.EmailField(max_length=50,unique=True)
    password = models.CharField(max_length=50)
    
    def register(self):
        self.save()
    
    
    @classmethod
    def isexist(cls, email):
        return cls.objects.filter(email=email).exists()
    
    def getcustomer(email):
        try:
            return Customer_info.objects.get(email =email)
        except:
            return False
    
    

