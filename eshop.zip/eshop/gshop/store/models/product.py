
from django.db import models
from .category import Category
class Products(models.Model):
    name = models.CharField(max_length=100)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category , on_delete = models.CASCADE , default= 1)
    descritption = models.CharField(max_length=200 , default="" , null=True ,blank=True)
    image = models.ImageField(upload_to="upload/products/")

    @staticmethod
    def get_all_products():
        return Products.objects.all()
    @staticmethod
    def get_all_products_by_categoryid( Category_id):
        if Category_id:
          return Products.objects.filter(category_id = Category_id)
        else:
            Products.get_all_products()

    @staticmethod
    def get_products_by_id(ids):
        return Products.objects.filter(id__in = ids)