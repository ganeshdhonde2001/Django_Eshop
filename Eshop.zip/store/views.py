from django.shortcuts import render,redirect,HttpResponsePermanentRedirect
from django.http import HttpResponse
from store.models.product import Products
from store.models.category import Category
from store.models.customer import Customer_info
from store.models.orders import Orders
from django.contrib.auth.hashers import make_password,check_password
from django.views import View

# Create your views here.
class index(View):
    def post(self,request):
        product = request.POST.get("product")
        remove = request.POST.get("remove")
        cart = request.session.get("cart")
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                       cart.pop(product)
                    else:
                       cart[product] = quantity-1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session["cart" ] = cart
        print(request.session["cart" ])

        return redirect ("homepage")
    
    def get(self,request):
            cart = request.session.get("cart")
            if not cart:
                request.session["cart"] = {}
            products = None
            categories = Category.get_all_categories()
            CategoryID = request.GET.get('category')
            if CategoryID:
                products = Products.get_all_products_by_categoryid(CategoryID)
            else:
                products = Products.get_all_products()

            data = {}
            data["products"] = products
            data["categories"] = categories
            print("you are :",request.session.get("email"))
            #   return render (request , "order.html")
            return render(request ,"index.html",data)

 

def signup(request):

    if request.method == "GET":
        return render(request, "signup.html")
    else:
        postData = request.POST
        first_name = postData.get("firstname")
        last_name = postData.get("lastname")
        mobile_number = postData.get("mobile")
        email = postData.get("email")
        password = postData.get("password")

        # Validation
        data = {
            "firstname": first_name,
            "lastname": last_name,
            "mobilenumber": mobile_number,
            "email": email
        }
        error_message = None

        if not first_name:
            error_message = "First Name Required..!!"
        elif len(first_name) < 4:
            error_message = "First name must be at least 4 characters long..!!"
        elif not last_name:
            error_message = "Last Name Required...!!"
        elif len(last_name) < 4:
            error_message = "Last name must be at least 4 characters long..!!"
        elif not mobile_number:
            error_message = "Mobile number is required..!!"
        elif len(mobile_number) != 10:
            error_message = "Enter a valid mobile number..!!"
        elif Customer_info.isexist(email):
            error_message = "Email already registered..!!"
        elif not password:
            error_message = "Password is required..!!"
        elif len(password) < 8:
            error_message = "Password must be at least 8 characters long..!!"

        if error_message:
            # Re-render the form with error and previously entered data
            return render(request, "signup.html", {
                "error": error_message,
                "values": postData,
                "data": data
            })
        else:
            # Hashing the password
            hashed_password = make_password(password)

            # Creating and saving the customer
            customer = Customer_info(
                firstname=first_name,
                lastname=last_name,
                mobilenumber=mobile_number,
                email=email,
                password=hashed_password
            )
            customer.register()
            return redirect("homepage")
class Login(View):
     return_url = None
     def get(self,request):
            Login.return_url = request.GET.get("return_url")
            return render (request, "login.html")
     def post(self,request):
        email = request.POST.get("email")
        password = request.POST.get("password")
        customer = Customer_info.getcustomer(email)
        error_message = None
        if customer:
           flag = check_password(password,customer.password)
           if flag:
                request.session["customer"] = customer.id
                if Login.return_url:
                    return HttpResponsePermanentRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect("homepage")
           else:
                error_message = "email or password invalid ...!!"
        else:
            error_message = "email or password invalid ...!!"

        return render (request,"login.html",{"error" :error_message})
     
def logout(request):
        request.session.clear()
        return redirect ("login")
     
def cart(request):
        ids = list(request.session.get("cart").keys())
        products = Products.get_products_by_id(ids)
        print(products)
        return render (request,"cart.html",{"products":products})

class Checkout(View):
    def post(self, request):
        address = request.POST.get("address")
        phone = request.POST.get("phone")
        customer_id = request.session.get("customer")  # Get the customer ID from the session
        cart = request.session.get("cart")
        product_ids = list(cart.keys())
        products = Products.get_products_by_id(product_ids)
        
        try:
            # Fetch the Customer_info object
            customer = Customer_info.objects.get(id=customer_id)
        except Customer_info.DoesNotExist:
            return redirect("cart")  # Redirect if the customer does not exist
        
        for product in products:
            quantity = cart.get(str(product.id), 0)  # Get quantity for the product
            
            if quantity > 0:
                # Create an order
                order = Orders(
                    customer=customer,  # Pass the customer instance
                    product=product,
                    address=address,
                    phone=phone,
                    price=product.price,
                    quantity=quantity
                )
                
                order.placeOrder()  # Save the order
                print("Order placed successfully.")
        
        # Clear the cart from the session
        request.session['cart'] = {}
        request.session.modified = True
        
        return redirect("cart")  # Redirect to the cart page
    
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
class Order(View):
    @method_decorator(auth_middleware)
    def get(self,request):
        customer = request.session.get("customer")
        orders = Orders.get_orders_by_customer(customer)
        return render (request,"orders.html",{"orders":orders})
    



        