from django.db import models
from .product import Products
from .customer import Customer_info
import datetime

class Orders(models.Model):
   product = models.ForeignKey(Products,on_delete=models.CASCADE)
   customer =  models.ForeignKey(Customer_info,on_delete=models.CASCADE)
   quantity = models.IntegerField(default = 1)
   address = models.CharField(max_length=200,default="",blank=True)
   phone = models.CharField(max_length=200,default="",blank=True)
   price = models.IntegerField()
   date = models.DateTimeField(default=datetime.datetime.now)
   status = models.BooleanField(default=False)

   def placeOrder(self):
      self.save()

   @staticmethod
   def get_orders_by_customer(customer_id):
         return Orders.objects.filter(customer=customer_id).order_by('-date')


